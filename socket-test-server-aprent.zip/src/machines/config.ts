export const config = {
  id: "endpoint_tester",
  initial: "start",
  entry: ["logSpawnningSocketServer", "spawnSocketServer"],
  states: {
    start: {
      invoke: [
        // {
        //   id: "kafka-producer",
        //   src: "kafkaProducer",
        // },
        // {
        //   id: "kafka-consumer",
        //   src: "kafkaConsumer",
        // },
      ],
      on: {
        SEND_TO_TOPIC: {
          actions: ["logProduceToWorkflow", "produceToWorkflow"],
        },
        WORKFLOW_RESPONSE: {
          actions: [
            "logSendToSocketServerToEmitResponse",
            "sendToSocketServerToEmitResponse",
          ],
        },
      },
    },
  },
};
