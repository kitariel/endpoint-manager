import { MachineOptions, assign, spawn, send } from "xstate";

import { IContext } from "./types";

import { spawn as spawnSocketServer } from "@xstate-machines/socket-server";
import { spawn as spawnKafkaProducer } from "@xstate-machines/kafkajs-producer";
import { spawn as spawnKafkaConsumer } from "@xstate-machines/kafkajs-consumer";

import { ENDPOINT_PRODUCER_TOPIC } from "../utils/env";

const DATE_START = new Date().toISOString();
const END_POINT = "END POINT";

export const implementation: MachineOptions<IContext, any> = {
  actions: {
    logSpawnningSocketServer: () =>
      console.log(`[${DATE_START}][${END_POINT}]: #logSpawnningSocketServer`),
    logProduceToWorkflow: (
      _,
      {
        type,
        payload: {
          type: payloadtype,
          session_id,
          workflow_id,
          payload: payloadinternal,
        },
      }: any
    ) => {
      const { type: payloadtypeinternal, data } = payloadinternal;
      console.table({
        type: [type],
        tracker_payload: [payloadtype],
        worker_payload: [payloadtypeinternal],
        session_id: [session_id],
        workflow_id: [workflow_id],
        data: [data],
      });
    },
    logSendToSocketServerToEmitResponse: (_, event) => {
      console.log(
        `[${DATE_START}][${END_POINT}]: logSendToSocketServerToEmitResponse`,
        event
      );
    },

    spawnSocketServer: assign({
      socket_instance: ({ socket_server }) => {
        const { socket_config } = socket_server;
        const instance = spawnSocketServer({
          socket_config,
        });
        return spawn(instance);
      },
    }),

    produceToWorkflow: send(
      (_, event: any): any => {
        const { type, payload } = event;
        return {
          type,
          topic: ENDPOINT_PRODUCER_TOPIC,
          message: payload,
        };
      },
      { to: "kafka-producer" }
    ),
    sendToSocketServerToEmitResponse: send(
      (_, event: any) => {
        return event;
      },
      { to: ({ socket_instance }) => socket_instance }
    ),
  },
  activities: {},
  delays: {},
  guards: {},
  services: {
    kafkaProducer: ({ kafka_producer_config }) => {
      return spawnKafkaProducer(kafka_producer_config);
    },
    kafkaConsumer: ({ kafka_consumer_config }) => {
      return spawnKafkaConsumer(kafka_consumer_config);
    },
  },
};
